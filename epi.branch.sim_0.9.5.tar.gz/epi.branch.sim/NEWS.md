# epi.branch.sim 

* Added a `NEWS.md` file to track changes to the package.

0.9.5: Added `daily_constant` as an import option
