## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(epi.branch.sim)
set.seed(3483)

## ----setup disease params-----------------------------------------------------
R0 <- 2.5
infect_dur <- 14  # in days
p_symp  <- 0.8 # percentage of cases that will be symptomatic
incub_params <- list(dist='lognormal',meanlog=1.57, sdlog=0.65) # distribution returns a value in days
serial_int_params <- list(dist='gamma', shape=2.29, rate=0.36)  # distribution returns a value in days
sec_infect_params <- list(type='Hellewell', disp=0.58) # 0.58 is the negative binomial dispersion parameter

## ----setup tracing params-----------------------------------------------------
# Contact tracing parameters
do_variable_trace <- FALSE # use a constant tracing value (see next line)
p_trace <- 0.75 # all cases have a 75% chance of being traced
p_trace_app <- 0.75 # percentage of population using a contact tracing app
p_trace_app_comp <- 0.75 # percentage of population complying with contact tracing app isolation instructions

## ----setup isolation----------------------------------------------------------
# Set delays to isolation 
iso_delay_params <- list(
  dist='uniform', # the following are min/max ranges of a uniform distribution
  traced_min = 1, # traced secondary cases isolated 1-3 days after index case isolated
  traced_max = 3,
  untraced_min = 4, # untraced secondary cases isolated 4-5 days after *symptom onset*
  untraced_max = 5,
  untraced_pd_min = 2, # untraced secondary cases which are distancing isolated earlier
  untraced_pd_max = 3
)

## ----setup distancing---------------------------------------------------------
pd_params <- list(
  pd_pop_frac = 0.8, # 80% of population are distancing
  pd_contact_rate1 = 1.0, # initial fraction of contacts for distancing group 
  pd_contact_rate2 = 0.3, # final fraction of contacts for distancing group 
  pd_change_t = 7 # simulation day number where the contact rate changes
)

## ----setup sim----------------------------------------------------------------
start_time <- 0 # start at time 0 (recommended)
dt <- 1 # timestep, in days
tmax <- 30 # total number of days in simulation
n_initial <- 3 # number of cases on day 0
import_params <- list(
  type = 'constant',
  rate = 1,  # one new import every day
  iso_lengths = 0, # number of days that imported cases might self-isolate upon arrival
  iso_p.group = 1  # probability that an imported case will do the above self-isolation
)

## ----create sim objects-------------------------------------------------------
sim_params <- initialize_sim_params(
  R0, infect_dur, do_variable_trace, p_trace, 
  p_trace_app, p_trace_app_comp, p_symp, dt,
  incub_params, serial_int_params,
  iso_delay_params, sec_infect_params,
  import_params, pd_params)
sim_status <- initialize_sim_status(start_time,n_initial) 
state_df   <- create_state_df(n_initial,sim_params, sim_status, initialize=TRUE)
record_df  <- create_record_df(state_df, sim_status, initialize=TRUE)

## ----peek sim_status----------------------------------------------------------
print(sim_status)

## ----peek state_df------------------------------------------------------------
head(state_df)

## ----peek record_df-----------------------------------------------------------
head(record_df)

## ----run first step-----------------------------------------------------------
out <- step_simulation(sim_status, state_df, record_df, sim_params)
sim_status <- out$status
state_df <- out$state
record_df <- out$record

## ----check sim_status---------------------------------------------------------
print(sim_status)

## ----check state_df-----------------------------------------------------------
head(state_df)

## ----check record_df----------------------------------------------------------
head(record_df)

## ----finish sim---------------------------------------------------------------
for (t in (1+sim_status$t):tmax){ # t takes values 2,3,4,5,...30 (tmax)
  out <- step_simulation(sim_status, state_df, record_df, sim_params)
  sim_status <- out$status # update sim_status
  state_df <- out$state    # update state_df
  record_df <- out$record  # update record_df
}

## ----check end of sim---------------------------------------------------------
sim_status$t
nrow(state_df)
nrow(record_df)

## ----check head state_df------------------------------------------------------
head(state_df, n=5)

## ----check tail state_df------------------------------------------------------
tail(state_df, n=5)

## ----check head record_df-----------------------------------------------------
head(record_df, n=5)

## ----echo=TRUE, count_cases---------------------------------------------------
(n.active <- nrow(state_df)) # all statuses except isolated or inactive
(n.total <- nrow(record_df)) # all cases, active or not
(n.incubation <- sum(record_df$s.status=='incubation')) # or any other status
(n.traced_by_app <- sum(record_df$is.traced_by_app))
(n.imported <- sum(record_df$source=='imported'))

## ----examine_out--------------------------------------------------------------
names(out)
print(out$new_sec_cases)
print(out$new_imp_cases)

## ----calc_Reff----------------------------------------------------------------
Reff <- mean(record_df$n.sec_infects)
print(Reff)

## ----calc_Rt7-----------------------------------------------------------------
rec_df_last7 <- subset(record_df, t_inf > tmax-7) # record_df for infections from last 7 days
Rt <- mean(rec_df_last7$n.sec_infects)
print(Rt)

