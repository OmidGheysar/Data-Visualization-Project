## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(epi.branch.sim)

## ----sim_status_arguments-----------------------------------------------------
names(formals(initialize_sim_status))

## ----sim_params_arguments-----------------------------------------------------
names(formals(initialize_sim_params))

## ----incub_example_bi---------------------------------------------------------
incub_params <- list(
  dist='lognormal',
  meanlog=1.57,
  sdlog=0.65
) 

## ----incub_example_hellewell--------------------------------------------------
incub_params <- list(
  dist='weibull', 
  shape=2.322737, 
  scale=6.492272
)

## ----serial_int_example_bi----------------------------------------------------
serial_int_params <- list(
  dist='gamma', 
  shape=2.29, 
  rate=0.36
)

## ----serial_int_example_hellewell---------------------------------------------
serial_int_params <- list(
  dist='skew_norm', 
  omega=2, 
  alpha=1.95
)

## ----sec_infect_Hellewell-----------------------------------------------------
sec_infect_params <- list(
  type='Hellewell',
  disp=0.16
)

## ----sec_infect_Bi------------------------------------------------------------
sec_infect_params <- list(
  type='Hellewell',
  disp=0.58
)

## ----phys_dist_ex_switchon7---------------------------------------------------
phys_dist_params <- list(
  pd_pop_frac=0.8,
  pd_contact_rate1=1.0,
  pd_contact_rate2=0.3,
  pd_change_t=14
)

## ----phys_dist_ex_reopen------------------------------------------------------
phys_dist_params <- list(
  pd_pop_frac=0.8,
  pd_contact_rate1=0.3,
  pd_contact_rate2=0.6,
  pd_change_t=30
)

## ----phys_dist_ex_constant----------------------------------------------------
phys_dist_params <- list(
  pd_pop_frac=0.8,
  pd_contact_rate1=0.3,
  pd_contact_rate2=0.3,
  pd_change_t=0 # or a number larger than the simulation end time, e.g. 999
)

## ----phys_dist_ex_no_PD-------------------------------------------------------
phys_dist_params <- list(
  pd_pop_frac=0,
  pd_contact_rate1=1.0,
  pd_contact_rate2=1.0,
  pd_change_t=0
)

## ----iso_delay_Hellewell------------------------------------------------------
iso_delay_params <- list(
  dist='Hellewell',
  shape=1.651524,
  scale=4.287786
)

## ----iso_delay_uniform--------------------------------------------------------
iso_delay_params <- list(
  traced_min=1,
  traced_max=2,
  untraced_min=4,
  untraced_max=5,
  untraced_pd_min=2,
  untraced_pd_max=3
)

## ----import_example_none------------------------------------------------------
import_params <- list(type='None')  

## ----import_example_daily-----------------------------------------------------
import_params <- list(
  type='daily_risk',
  risk=c(1.5,3,5.1,10,0.5),
  iso_p_groups=c(1),
  iso_lengths=c(0)
)

## ----import_example_constant--------------------------------------------------
import_params <- list(
  type='constant',
  rate=10,
  iso_p_groups=c(0.5,0.25,0.25),
  iso_lenghts=c(14,7,0)
)

## ----import_example_2phase----------------------------------------------------
import_params <- list(
  type='constant_two_phase',
  delay=14,
  rate1=0,
  rate2=10,
  iso_p_groups=c(1),
  iso_lengths=c(3)
)

